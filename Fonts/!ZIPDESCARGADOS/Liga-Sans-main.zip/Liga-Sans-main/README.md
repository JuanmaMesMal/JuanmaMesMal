# Liga-Sans<br>
An inclusive genderfuck sans-serif typeface tailored for Manon Didierjean's book 'Beyond Human' published in 2021 <br>
With special ligatures proposing an inclusive/non-gendered way to express yourself through French language.<br>
Since then I've been updating in early 2022 a 2.0 version containing a list of the most common words used in English language and contracted them in tiny ligatures to save some space in a funny way.<br>
Now working on a 2.1 release that will be proposing more tiny English common words, also introducign French tiny common words & English genderfluid ligatures.<br><br>

Thanks for your interest! Feel free to use/modify/distribute<br>
           Please tag/credit ＿ﾉ乙(､ﾝ､)＿<br>
            Find me on Instagram @nathan.laurent.xyz<br>
              I'm open to any suggestions for future updates! (￣▽￣)ノ
